<svelte:head>
	<link rel="stylesheet" href="./reset.css" />
</svelte:head>

<slot />