<script lang="ts">
	import { onMount } from 'svelte';
	import { base64_current, photo_clicked } from './store/base64_image';
	let canvasElement: HTMLCanvasElement;

	async function startCamera() {
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ video: true });
			const videoElement = document.createElement('video');
			videoElement.srcObject = stream;

			await videoElement.play();

			const minSize = Math.min(videoElement.videoWidth, videoElement.videoHeight);
			canvasElement.width = minSize;
			canvasElement.height = minSize;

			const context = canvasElement.getContext('2d');

			function drawFrame() {
				if (!context) return;
				context.drawImage(
					videoElement,
					0,
					0,
					minSize,
					minSize,
					0,
					0,
					canvasElement.width,
					canvasElement.height
				);
				$base64_current = canvasElement.toDataURL('image/jpeg');
				requestAnimationFrame(drawFrame);
			}

			drawFrame();
		} catch (error) {
			console.error('Error accessing the camera');
			console.error(error);
		}
	}

	onMount(startCamera);
</script>

<div class="john" style="opacity: {$photo_clicked ? 1 : 0}">Nice 🤌 *chef's kiss*</div>
<canvas bind:this={canvasElement} />

<style>
	.john {
		position: absolute;
		top: 0;
		left: 0;
		height: 100vh;
		width: 100vw;
		background-color: black;
		color: white;
		font-size: 48px;
		display: flex;
		align-items: center;
		justify-content: center;
		font-weight: 900;
		transition: opacity 0.2s cubic-bezier(1, 0, 0, 1);
	}
	canvas {
		height: 100vh;
		width: 100vw;
		object-fit: contain;
	}
</style>
