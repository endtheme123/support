export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "_app",
	assets: new Set(["favicon.png","reset.css"]),
	mimeTypes: {".png":"image/png",".css":"text/css"},
	_: {
		client: {"start":"_app/immutable/entry/start.6620f181.js","app":"_app/immutable/entry/app.5efa7f3f.js","imports":["_app/immutable/entry/start.6620f181.js","_app/immutable/chunks/scheduler.e97979f3.js","_app/immutable/chunks/singletons.d75ce34f.js","_app/immutable/chunks/index.a9a32372.js","_app/immutable/entry/app.5efa7f3f.js","_app/immutable/chunks/scheduler.e97979f3.js","_app/immutable/chunks/index.22018d99.js"],"stylesheets":[],"fonts":[]},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js')),
			__memo(() => import('./nodes/3.js'))
		],
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			},
			{
				id: "/number",
				pattern: /^\/number\/?$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 3 },
				endpoint: null
			}
		],
		matchers: async () => {
			
			return {  };
		}
	}
}
})();
