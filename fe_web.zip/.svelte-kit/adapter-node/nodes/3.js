

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/number/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.d9b1e5fb.js","_app/immutable/chunks/scheduler.e97979f3.js","_app/immutable/chunks/index.22018d99.js"];
export const stylesheets = ["_app/immutable/assets/3.a018bec9.css"];
export const fonts = [];
