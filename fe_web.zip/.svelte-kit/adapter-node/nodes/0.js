

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.1c677db4.js","_app/immutable/chunks/scheduler.e97979f3.js","_app/immutable/chunks/index.22018d99.js"];
export const stylesheets = [];
export const fonts = [];
