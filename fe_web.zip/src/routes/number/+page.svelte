<!-- input text and fetch GET: localhost:8010/mnist/result?requestID=[requestid]-->
<script lang="ts">
	const url = 'http://localhost:8010/mnist/result?requestID=';
	let requestID = '';
	let result: null | string = null;
	let dot = '...';

	function fetchResult() {
		fetch(url + requestID)
			.then((res) => res.json())
			.then((data) => {
				console.log(data);
				result = data.data.result.prediction;
			});
	}

	function animateDot() {
		setTimeout(() => {
			if (dot.length === 3) {
				dot = '';
			} else {
				dot += '.';
			}
			animateDot();
		}, 500);
	}

	animateDot();
</script>

<div class="container">
	<h1>Please copy the previous request id and paste it here.</h1>
	<input
		type="text"
		bind:value={requestID}
		autocomplete="off"
		placeholder="Request ID"
		on:keydown={(e) => {
			if (e.key === 'Enter') {
				fetchResult();
			}
		}}
	/>
	<button on:click={fetchResult}>Get Result</button>
	<p>
		No fancy GUI here sorry, the dev is too lazy to make one. Just input the requestID and click the
		button to fetch.
	</p>

	<p class="result">
		{#if result}
			Prediction: {result}
		{:else}
			Waiting{dot}
		{/if}
	</p>
</div>

<style>
	.container {
		position: absolute;
		top: 0;
		left: 0;
		height: 100vh;
		width: 100vw;
		background-color: #1a1a1a;
		color: white;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		gap: 12px;
	}

	input {
		padding: 12px;
		border-radius: 12px;
		border: none;
		outline: none;
		width: 300px;
		background-color: transparent;
		color: white;
		border: 1px solid white;
		text-align: center;
	}

	button {
		padding: 6px 12px;
		border-radius: 12px;
		border: none;
		outline: none;
		background-color: transparent;
		color: white;
		border: 1px solid white;
		cursor: pointer;
	}

	button:active {
		transform: scale(0.9);
	}

	.result {
		font-size: 24px;
		margin: 0;
		margin-top: 12px;
		font-family: monospace;
	}
</style>
