import { writable } from "svelte/store";

export const base64_current = writable<string | null>(null);
export const photo_clicked = writable<boolean>(false);