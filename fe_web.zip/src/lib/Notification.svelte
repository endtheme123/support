<script lang="ts">
	export let title: string;
	export let message: string;
	let content_div: HTMLDivElement;
</script>

<div class="notify" bind:this={content_div}>
	<h1 class="title">{title}</h1>
	<div class="content">
		<p>{message}</p>
		<button on:click={() => {
			navigator.clipboard.writeText(message);
			content_div.remove();
		}}>Copy and close</button>
	</div>
</div>

<style lang="scss">
	.notify {
		position: fixed;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		height: 300px;
		width: 400px;
		border-radius: 6px;
		overflow: hidden;
		background-color: white;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
		border: 1px solid black;
	}

	.title {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 36px;
		display: flex;
		align-items: center;
		justify-content: center;
		border-bottom: 1px solid black;
	}

	.content {
		position: absolute;
		top: 36px;
		left: 0;
		width: 100%;
		height: calc(100% - 36px);
		overflow: hidden;
		padding: 12px;
		p {
			position: absolute;
			top: 0;
			left: 0;
			overflow: hidden;
			overflow-y: auto;
			height: calc(100% - 24px);
			width: calc(100% - 24px);
			margin: 12px;
		}
		button {
			position: absolute;
			bottom: 30px;
			right: 30px;
		}
	}
</style>
