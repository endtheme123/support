import { c as create_ssr_component, b as add_attribute, e as escape } from "../../../chunks/ssr.js";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: ".container.svelte-jo88sc{position:absolute;top:0;left:0;height:100vh;width:100vw;background-color:#1a1a1a;color:white;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px}input.svelte-jo88sc{padding:12px;border-radius:12px;border:none;outline:none;width:300px;background-color:transparent;color:white;border:1px solid white;text-align:center}button.svelte-jo88sc{padding:6px 12px;border-radius:12px;border:none;outline:none;background-color:transparent;color:white;border:1px solid white;cursor:pointer}button.svelte-jo88sc:active{transform:scale(0.9)}.result.svelte-jo88sc{font-size:24px;margin:0;margin-top:12px;font-family:monospace}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let requestID = "";
  let dot = "...";
  function animateDot() {
    setTimeout(
      () => {
        if (dot.length === 3) {
          dot = "";
        } else {
          dot += ".";
        }
        animateDot();
      },
      500
    );
  }
  animateDot();
  $$result.css.add(css);
  return `  <div class="container svelte-jo88sc"><h1 data-svelte-h="svelte-1w1lin0">Please copy the previous request id and paste it here.</h1> <input type="text" autocomplete="off" placeholder="Request ID" class="svelte-jo88sc"${add_attribute("value", requestID, 0)}> <button class="svelte-jo88sc" data-svelte-h="svelte-ay8buu">Get Result</button> <p data-svelte-h="svelte-akhs6o">No fancy GUI here sorry, the dev is too lazy to make one. Just input the requestID and click the
		button to fetch.</p> <p class="result svelte-jo88sc">${`Waiting${escape(dot)}`}</p> </div>`;
});
export {
  Page as default
};
