<script lang="ts">
	import Camera from '$lib/Camera.svelte';
	import Notification from '$lib/Notification.svelte';
	import { base64_current, photo_clicked } from '$lib/store/base64_image';
	import { onMount } from 'svelte';

	const DJANGO_PORT = 8010;
	const url = `http://192.168.1.108:${DJANGO_PORT}/mnist/upload`;
	let hideNotify = false;
	let left_dot_on = false;
	let right_dot_on = false;
	let output = '';

	onMount(() => {
		window.addEventListener('keydown', (e) => {
			if (e.key === 'Enter') {
				captured();
			}
		});
	});

	function captured() {
		$photo_clicked = true;
		setTimeout(() => {
			$photo_clicked = false;
			output = $base64_current?.split(',')[1] as string;
			console.log(output);
			const data = { inputImg: output };
			fetch(url, {
				method: 'POST',
				body: JSON.stringify(data),
				headers: {
					'Content-Type': 'application/json'
				}
			})
				.then((res) => res.json())
				.then((data) => {
					const title = 'Upload success!';
					const message = data.data.request_id;
					new Notification({ target: document.body, props: { title, message } });
				});
		}, 500);
	}

	async function handleDropNum(event: DragEvent) {
		event.preventDefault();
		const file = event.dataTransfer?.files[0];
		left_dot_on = false;
		if (!file?.type.includes('image')) {
			alert('Please upload image file');
			return;
		}
		const b64 = (await crop_image_to_square_image(file)) as string;
		const data = { inputImg: b64.split(',')[1] };
		console.log(data);
		fetch(url, {
			method: 'POST',
			body: JSON.stringify(data),
			headers: {
				'Content-Type': 'application/json'
			}
		})
			.then((res) => res.json())
			.then((data) => {
				const title = 'Upload success!';
				const message = data.data.request_id;
				new Notification({ target: document.body, props: { title, message } });
			});
	}

	async function handleDropObj(event: DragEvent) {
		event.preventDefault();
		right_dot_on = false;
		const file = event.dataTransfer?.files[0];
		if (!file?.type.includes('image')) {
			alert('Please upload image file');
			return;
		}
		const b64 = await crop_image_to_square_image(file);
	}

	function crop_image_to_square_image(image: File) {
		return new Promise((resolve, reject) => {
			const reader = new FileReader();
			reader.readAsDataURL(image);
			reader.onload = () => {
				const img = new Image();
				img.src = reader.result as string;
				img.onload = () => {
					const canvas = document.createElement('canvas');
					const ctx = canvas.getContext('2d');
					const minSize = Math.min(img.width, img.height);
					const startX = (img.width - minSize) / 2;
					const startY = (img.height - minSize) / 2;
					canvas.width = minSize;
					canvas.height = minSize;
					ctx?.drawImage(img, startX, startY, minSize, minSize, 0, 0, canvas.width, canvas.height);
					resolve(canvas.toDataURL('image/jpeg'));
				};
			};
			reader.onerror = (error) => reject(error);
		});
	}
</script>

<div class="notify" style="display: {hideNotify ? 'none' : 'block'}">
	<h1>SwinCV project: Number detection and Object detection</h1>
	<p>
		Note: to make it easier to determine the number, fill the photo with a blank sheet of paper.
		Then, write a number you want to find in bold strokes and then press the enter key or the
		capture button below the screen.
	</p>
	<p>
		Note 2: for best result, please upload image with monochrome backgrounds and numbers always
		placed in the center. You can drag and drop the image to the screen in order to upload it.
	</p>
	<p>
		Note 3: Deadline destroys my creativity so this is definitely the ugliest website. I'm sorry for
		your eyes. Click the X button to close this notification.
	</p>
	<p>Note 4: After getting request id, please use: [this url]/number to get the prediction.</p>
	<button
		class="close"
		on:click={() => {
			hideNotify = true;
		}}
	>
		X
	</button>
</div>

<div class="camera">
	<Camera />
</div>

<div
	class="left_area"
	on:dragover={(event) => {
		event.preventDefault();
		left_dot_on = true;
	}}
	on:dragleave={(event) => {
		event.preventDefault();
		left_dot_on = false;
	}}
	on:drop={async (event) => {
		await handleDropNum(event);
	}}
	role="list"
>
	<div class="dot{left_dot_on ? ' full_dot' : ''}">
		<p>[Number detection]</p>
	</div>
</div>
<div
	class="right_area"
	role="list"
	on:dragover={(event) => {
		event.preventDefault();
		right_dot_on = true;
	}}
	on:dragleave={(event) => {
		event.preventDefault();
		right_dot_on = false;
	}}
	on:drop={async (event) => {
		await handleDropObj(event);
	}}
>
	<div class="dot{right_dot_on ? ' full_dot2' : ''}">
		<p>[Object detection]</p>
	</div>
</div>

<button
	class="circle"
	title="Number detection"
	on:click={() => {
		captured();
	}}
>
	<svg xmlns="http://www.w3.org/2000/svg" height="48" viewBox="0 -960 960 960" width="48"
		><path
			d="M220-366v-190h-70v-38h108v228h-38Zm134 0v-97q0-15.3 10.35-25.65Q374.7-499 390-499h96v-57H354v-38h134q15.3 0 25.65 10.35Q524-573.3 524-558v61q0 15.3-10.35 25.65Q503.3-461 488-461h-96v57h132v38H354Zm256 0v-38h142v-57H650v-38h102v-57H610v-38h144.293q14.607 0 25.157 10.35T790-558v156q0 15.3-10.35 25.65Q769.3-366 754-366H610Z"
		/></svg
	>
</button>

<button
	class="circle2"
	title="Object detection"
	on:click={() => {
		// captured();
	}}
>
	<svg xmlns="http://www.w3.org/2000/svg" height="36" viewBox="0 -960 960 960" width="36"
		><path
			d="M356.662-387Q336-387 320.5-402.838t-15.5-37Q305-461 320.838-476t37-15Q379-491 394-475.532t15 36.87Q409-418 393.532-402.5t-36.87 15.5Zm246 0Q582-387 566.5-402.838t-15.5-37Q551-461 566.838-476t37-15Q625-491 640-475.532t15 36.87Q655-418 639.532-402.5t-36.87 15.5ZM480.084-151q137.291 0 233.104-95.974Q809-342.948 809-480.047q0-24.555-3.5-48.333T795.448-573q-21.448 5-43.386 7.5-21.939 2.5-46.053 2.5-93.124 0-176.566-40Q446-643 387-714q-31.722 78.316-93.204 138.311Q232.313-515.693 151-485.411V-479.586q0 136.842 95.896 232.714Q342.792-151 480.084-151Zm.09 35q-74.814 0-141.626-28.622-66.812-28.622-116.234-77.688t-77.868-115.884Q116-405.012 116-479.826q0-74.814 28.622-141.626 28.622-66.811 77.688-116.234 49.066-49.422 115.884-77.868Q405.012-844 479.826-844q74.814 0 141.626 28.622 66.811 28.622 116.234 77.688 49.422 49.066 77.868 115.884Q844-554.988 844-480.174q0 74.814-28.622 141.626-28.622 66.812-77.688 116.234t-115.884 77.868Q554.988-116 480.174-116ZM378-794q67 115 160 155.5T706-598q21 0 39.625-1.8T782-608q-40-95-122-148t-180-53q-32.4 0-56.7 3.5Q399-802 378-794ZM159-532q52-19 124.5-83.5T365-786q-91 32-143.5 100.5T159-532Zm219-262Zm-13 8Z"
		/></svg
	>
</button>

<style lang="scss">
	@import '$lib/style/dragndrop.scss';

	:global(body) {
		font-family: sans-serif !important;
		background: black !important;
	}
	.camera {
		position: absolute;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		overflow: hidden;
		z-index: -1;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.circle,
	.circle2 {
		position: fixed;
		bottom: 12px;
		left: 50%;
		transform: translateX(calc(-50% - 48px));
		width: 72px;
		height: 72px;
		background-color: rgba(255, 255, 255, 0.4);
		backdrop-filter: blur(10px);
		border-radius: 50%;
		border: 1px solid black;
		display: flex;
		justify-content: center;
		align-items: center;
		transition: transform 0.5s cubic-bezier(0, 1, 0, 1);
	}

	.circle {
		&:hover {
			transform: translateX(calc(-50% - 48px)) scale(0.9);
		}
		&:active {
			transform: translateX(calc(-50% - 48px)) scale(0.8);
		}
	}

	.circle2 {
		transform: translateX(calc(-50% + 48px));
		&:hover {
			transform: translateX(calc(-50% + 48px)) scale(0.9);
		}
		&:active {
			transform: translateX(calc(-50% + 48px)) scale(0.8);
		}
	}

	.notify {
		position: fixed;
		top: 12px;
		left: 12px;
		margin-right: 12px;
		padding: 12px;
		background-color: rgba(255, 255, 255, 0.4);
		backdrop-filter: blur(10px);
		border-radius: 12px;
		border: 1px solid black;
		overflow: hidden;
		overflow-y: scroll;
		z-index: 1000;
		h1 {
			font-size: 24px;
			margin: 0;
			margin-bottom: 12px;
		}
		p {
			font-size: 16px;
			margin: 0;
			margin-bottom: 12px;
		}
		.close {
			position: fixed;
			bottom: 12px;
			right: 12px;
			height: 32px;
			width: 32px;
			border-radius: 50%;
			border: 1px solid black;
			background: transparent;
		}
		&::-webkit-scrollbar {
			display: none;
		}
	}
</style>
